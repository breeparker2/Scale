
#-----Statement of Authorship----------------------------------------#
#
#  This is an individual assessment task for QUT's teaching unit
#  IFB104, "Building IT Systems", Semester 1, 2024.  By submitting
#  this code I agree that it represents my own work.  I am aware of
#  the University rule that a student must not act in a manner
#  which constitutes academic dishonesty as stated and explained
#  in QUT's Manual of Policies and Procedures, Section C/5.3
#  "Academic Integrity" and Section E/2.1 "Student Code of Conduct".
#
#  Put your student number here as an integer and your name as a
#  character string:
#
student_number = 9142622
student_name   = "Bree Parker"
#
#  NB: All files submitted for this assessable task will be subjected
#  to automated plagiarism analysis using a tool such as the Measure
#  of Software Similarity (http://theory.stanford.edu/~aiken/moss/).
#
#--------------------------------------------------------------------#



#-----Assessment Task 1 Description----------------------------------#
#
#  This assessment task tests your skills at processing large data
#  sets, creating reusable code and following instructions to display
#  a complex visual image.  The incomplete Python program below is
#  missing a crucial function.  You are required to complete this
#  function so that when the program runs it fills a grid with various
#  symbols, using data stored in a list to determine which symbols to
#  draw and where.  See the online video instructions for
#  full details.
#
#  Note that this assessable assignment is in multiple parts,
#  simulating incremental release of instructions by a paying
#  "client".  This single template file will be used for all parts
#  and you will submit your final solution as this single Python 3
#  file only, whether or not you complete all requirements for the
#  assignment.
#
#  This file relies on other Python modules but all of your code
#  must appear in this file only.  You may not change any of the code
#  in the other modules and you should not submit the other modules
#  with your solution.  The markers will use their own copies of the
#  other modules to test your code, so your solution will not work
#  if it relies on changes made to any other files.
#
#--------------------------------------------------------------------#  



#-----Preamble-------------------------------------------------------#
#
# This section imports necessary functions used to execute your code.
# You must NOT change any of the code in this section, and you may
# NOT import any non-standard Python modules that need to be
# downloaded and installed separately.
#

# Import standard Python modules needed to complete this assignment.
# You should not need to use any other modules for your solution.
# In particular, your solution must NOT rely on any non-standard
# Python modules that need to be downloaded and installed separately,
# because the markers will not have access to such modules.
from turtle import *
from math import *
from random import *
from sys import exit as abort
from os.path import isfile

# Confirm that the student has declared their authorship
if not isinstance(student_number, int):
    print('\nUnable to run: No student number supplied',
          '(must be an integer), aborting!\n')
    abort()
if not isinstance(student_name, str):
    print('\nUnable to run: No student name supplied',
          '(must be a character string), aborting!\n')
    abort()

# Import the functions for setting up the drawing canvas
config_file = 'assignment_1_config.py'
if isfile(config_file):
    print('\nConfiguration module found ...\n')
    from assignment_1_config import *
else:
    print(f"\nCannot find file '{config_file}', aborting!\n")
    abort()

# Define the function for generating data sets in Task 1B,
# using the imported raw data generation function if available,
# but otherwise creating a dummy function that just returns an
# empty list
data_file = 'assignment_1_data.py'
if isfile(data_file):
    print('Data generation module found ...\n')
    from assignment_1_data import raw_data
    def data_set(new_seed = randint(0, 99999)):
        return raw_data(new_seed) # return the random data set
else:
    print('No data generation module available ...\n')
    def data_set(dummy_parameter = None):
        return []

#
#--------------------------------------------------------------------#



#-----Student's Solution---------------------------------------------#
#
#  Complete the assignment by replacing the dummy function below with
#  your own function and any other functions needed to support it.
#  All of your solution code must appear in this section.  Do NOT put
#  any of your code in any other sections and do NOT change any of
#  the provided code except as allowed by the comments in the next
#  section.
#

# All of your code goes in, or is called from, this function.
# In Task 1B ensure that your code does NOT call functions data_set
# or raw_data because they're already called in the main program
# below.

speed(0)
def visualise_data(data_set):
    global square_data
    global cell_size

#defining square shape
title("coffee sales")
def square(x, y, color):
    penup()
    goto(x, y)
    pendown()
    fillcolor(color)
    begin_fill()
    pensize(5)
    for _ in range(4):
      forward(80)
      right(90)
    end_fill()
    penup()

#defining coffee shape
def coffee(x, y, heading):
    penup()
    setheading(heading)
    goto(x, y)
    pendown()
    pencolor("#4B382A")
    fillcolor("#6F4E37")
    begin_fill()
    rad = 3 * 4.5 * 3.14
    pensize(4)
    for i in range(2):
     circle(rad, 90)
     circle(rad//2,90)
    end_fill()
    penup()
    
# defining the dent in the middle of the coffee shape
def inside(x, y, heading):
    setheading(heading)
    goto(x, y)
    pendown()
    pencolor("#4B382A")
    pensize(10)
    circle(19.5 ,130)
    left(-220)
    circle(19.5,-100)
    penup()

def inside_2(x, y, heading):
    setheading(heading)
    goto(x, y)
    pensize(10)
    pendown()
    right(90)
    circle(8.5,-100)
    penup()

# defining drawing shape 
def draw_shapes():
    for (x, y), color in square_data:
        square(x, y, color)

    for (x, y), heading in coffee_data:
        coffee(x, y, heading)

    for (x, y), heading in inside_data:
        inside(x, y, heading)

    for (x, y), heading in inside_2_data:
        inside_2(x, y, heading)
        
# calling drawings of each shape
square_data = [
    ((-630, 140), "green"),
    ((-630, 40), "yellow"),
    ((-630, -60), "red"),
    ]

coffee_data = [
    ((-575, 70),40),
    ((-559, 10), 132),
    ((-575, -130), 45),
    ]

inside_data = [
    ((-585, 131), 205),
    ((-558, -5), 125),
    ((-593, -131), 30),
    ]

inside_2_data = [
    ((-580, 68), 75),
    ((-563, 6), 150),
    ((-601, -70), 240),
    ]




data = data_set()
visualise_data(data)

month_coordinates = { "January": 0,
                "February": 1,
                "March": 2,
                "April": 3,
                "May": 4,
                "June": 5,
                "July": 6,
                "August": 7,
                "September": 8,
                "October": 9,
                "November": 10,
                "December": 11}




# draw the shapes multiple times determined by performance
for i, (month, performance)in enumerate(data):
    # Calculating x-coordinate based on the month
    x_coordinate = (month_coordinates[month] * cell_size) - 400
    # y_coordinates because the drawings were visulaising slightly above the based line(0, 0)
    y_coordinate = 40

    if performance > 0:
        for j in range(performance):
            square_data.append(((x_coordinate, y_coordinate + (j * cell_size)), "green"))  # Above the 0 line

            coffee_data.append(((x_coordinate + 50 , y_coordinate + (j * cell_size)  - 70),  45))
            
            inside_data.append(((x_coordinate + 40, y_coordinate + (j * cell_size) - 8), 205))

            inside_2_data.append(((x_coordinate + 40, y_coordinate + (j * cell_size) - 72), 50))
    elif performance < 0:
        for j in range(-performance):
            square_data.append(((x_coordinate, y_coordinate - (j * cell_size)), "red"))  # Below the 0 line
            
            coffee_data.append(((x_coordinate + 60, y_coordinate - (j * cell_size) - 70),  45))

            inside_data.append(((x_coordinate + 50, y_coordinate - (j * cell_size) - 10), 205))

            inside_2_data.append(((x_coordinate + 38, y_coordinate - (j * cell_size) - 8), -110))        
    else:
        square_data.append(((x_coordinate, y_coordinate), "yellow"))

        coffee_data.append(((x_coordinate + 70 , y_coordinate - 30),  132))
        
        inside_data.append(((x_coordinate + 70, y_coordinate - 45), 125))

        inside_2_data.append(((x_coordinate + 66, y_coordinate - 30), 170))
        

# define function to calculate total sum of performance
def calculate_total_performance(data):
    total_performance = sum(performance for _, performance in data)
    return total_performance


# calculate total sum of performance levels from data
total_performance = calculate_total_performance(data)

# printing the total
def print_total_performance(total_performance):
    penup()
    goto(-600, -200)
    pendown()
    color("black")
    write(f"Total profit ($bn): {total_performance}", align="center", font=("Arial", 16, "normal"))

# calling the function to print the total performance levels
print_total_performance(total_performance)

#calling draw_shapes, the drawing canvas
create_drawing_canvas()
draw_shapes()
visualise_data(data)    


#
#--------------------------------------------------------------------#



#-----Main Program to Run Student's Solution-------------------------#
#
# This main program configures the drawing canvas, calls the student's
# function and closes the canvas.  Do NOT change any of this code
# except as allowed by the comments below.  Do NOT put any of
# your solution code in this section.
#

# Configure the drawing canvas
#
# ***** You can add arguments to this function call to modify
# ***** features of the drawing canvas such as the background
# ***** and line colours, etc
create_drawing_canvas()

# Create the data set and pass it to the student's function
#
# ***** While developing your Task 1B code you can call the
# ***** "data_set" function with a fixed seed below for the
# ***** random number generator, but your final solution must
# ***** work with "data_set()" as the function call,
# ***** i.e., for any random data set that can be returned by
# ***** the function when called with no seed
#visualise_data(data_set()) # <-- no argument for "data_set" when assessed

# Exit gracefully
#
# ***** Do not change this function call
release_drawing_canvas(student_name)

#
#--------------------------------------------------------------------#
